package edu.albany.abstractSupermarket;

import java.util.*;

public class Customers {
	public static Customers customer = null;
	
	//ArrayList of person who are customers before their purchase
	private ArrayList<Person> customerList = new ArrayList<>();
	
	//ArrayList of person that has completed the purchase
	private ArrayList<Person> customerDone = new ArrayList<>();
	
	//Constructor
	private Customers() {
		
	}
	
	public static Customers shop() {
		if(customer == null)
			customer = new Customers();
		return customer;
	}
	
	//Getter of the list of customers before purchase
	public ArrayList<Person> getCL(){
		return customerList;
	}
	
	//method to add person to customer list
	public void addPerson(Person p) {
		customerList.add(p);
	}
	
	//Getter of the customers after purchase
	public ArrayList<Person> getCD(){
		return customerDone;
	}
	
	//method to remove customer from customer list before their purchase and placing them into list of customer after purchase
	public void customerDone(Person p) {
		customerDone.add(p);
		customerList.remove(p);
	}
}
