package edu.albany.abstractSupermarket;

public class ShoppingBag {
	
	//Using polymorphism to create the order of the customer
	public Food sellFood(String order) {
		
		if(order.equals("Sandwich")){
			return new Sandwich();
		}
		else if(order.equals("Salad")){
			return new Salad();
		}
		else if(order.equals("Tea")){
			return new Tea();
		}
		else
			return null;
	}
}
