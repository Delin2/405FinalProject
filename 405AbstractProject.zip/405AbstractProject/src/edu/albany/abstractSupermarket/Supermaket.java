package edu.albany.abstractSupermarket;

public class Supermaket {

	public static void main(String[] args) {
		//Creates ShoppingBag
		ShoppingBag sb = new ShoppingBag();
		
		//list of person to be customers
		Person list[] = 
			{	new Person("Matt Stonie",25,sb.sellFood("Sandwich")),
				new Person("Luna",18,sb.sellFood("Salad")),
				new Person("Faker",21,sb.sellFood("Tea"))};
		
		//initialize customer
		Customers cust = Customers.shop();
		
		//Adding each person into customer list
		for(Person p : list) {
			cust.addPerson(p);
		}
		
		//Prints out each person in customerList 
		System.out.println("Customers: ");
		for(Person p : cust.getCL()) {
			System.out.println(p);
		}
		
		//Check out for customer and placing them from customerList to customerDone
		for(Person p : list) {
			System.out.println("Checking out for customer member " + p.getName());
			cust.customerDone(p);
		}
		
		//Prints out person in customerDone 
		System.out.println("\nSatisfied Customers:\n");
		for(Person p : cust.getCD()) {
			System.out.println(p);
		}
	}

}
