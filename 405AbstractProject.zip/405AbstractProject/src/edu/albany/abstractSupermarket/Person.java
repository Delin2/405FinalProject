package edu.albany.abstractSupermarket;

public class Person {
	public String name;
	public int age;
	private Food purchase = null;
	
	//Constructor 
	public Person(String name, int age, Food purchase) {
		super();
		this.name = name;
		this.age = age;
		this.purchase = purchase;
	}
	
	//Getter for name of person
	public String getName() {
		return name;
	}
	
	//Setter for name of person
	public void setName(String name) {
		this.name = name;
	}
	
	//Getter for age of person
	public int getAge() {
		return age;
	}
	
	//Setter for age of person
	public void setAge(int age) {
		this.age = age;
	}
	
	//Getter for purchase of person
	public Food getPurchase() {
		return purchase;
	}
	
	//Setter for purchase of person
	public void setPurchase(Food purchase) {
		this.purchase = purchase;
	}
	
	/*
	 * toString to print out: 	Name: (name of person)
	 * 							Age: (age of person)
	 * 							Food Purchased: (purchase of person)
	 */
	@Override
	public String toString(){
		return "Name: " + name + "\nAge: " + age +  "\nFood Purchased: " + purchase;
	}
}
