package edu.albany.abstractSupermarket;

public class Salad extends Food{
	//initializing Salad with Food fields
	public Salad(){
		setOrder("Salad");
		setPrice(3.99);
		setCalories(300);
		setTemp("Cold");
	}
}
