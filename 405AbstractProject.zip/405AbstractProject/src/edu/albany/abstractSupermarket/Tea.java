package edu.albany.abstractSupermarket;

public class Tea extends Food{
	//initializing Tea with Food fields
	public Tea(){
		setOrder("Tea");
		setPrice(1.99);
		setCalories(0);
		setTemp("Hot");
	}
}
