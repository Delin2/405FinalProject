package edu.albany.abstractSupermarket;

//An abstract class called Food
public abstract class Food {
	private String order;
	private double price;
	private int calories;
	private String temp;
	
	//Getter for order
	public String getOrder() {
		return order;
	}
	
	//setter for order
	public void setOrder(String order) {
		this.order = order;
	}
	
	//Getter for price
	public double getPrice() {
		return price;
	}
	
	//setter for price
	public void setPrice(double price){
		this.price = price;
	}
	
	//Getter for calories
	public int getCalories() {
		return calories;
	}	
	
	//setter for calories
	public void setCalories(int calories){
		this.calories = calories;
	}	
	
	//Getter for temp
	public String getTemp() {
		return temp;
	}
	
	//setter for temp
	public void setTemp(String temp) {
		this.temp = temp;
	}
	
	//toString to print out: A temp order for $price
	@Override
	public String toString(){
		return "A " +temp+ " " + order + " for $" + price + "\n";
		}
}
