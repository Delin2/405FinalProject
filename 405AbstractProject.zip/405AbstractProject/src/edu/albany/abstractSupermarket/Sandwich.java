package edu.albany.abstractSupermarket;

public class Sandwich extends Food{
	//initializing Sandwich with Food fields
	public Sandwich(){
		setOrder("Sandwich");
		setPrice(6.99);
		setCalories(350);
		setTemp("Warm");
	}
}
